<div class="footer">
  <div class="container">
    <div class="w3ls_footer_grid">
      <div class="col-md-6 w3ls_footer_grid_left">
        <div class="w3ls_footer_grid_left1">
          <h2>Subscribe to us</h2>
          <div class="w3ls_footer_grid_left1_pos">
            <form action="#" method="post" onsubmit="return false;">
              <input type="email" name="email" placeholder="Your email..." required="">
              <input type="submit" value="Send">
            </form>
          </div>
        </div>
      </div>
      <div class="col-md-6 w3ls_footer_grid_right">
        <a href="<?php echo e(route('home')); ?>"><h2>One<span>Movies</span></h2></a>
      </div>
      <div class="clearfix"> </div>
    </div>
    <div class="col-md-5 w3ls_footer_grid1_left">
      <p>&copy; <?php echo e(date('Y')); ?> One Movies. All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
    </div>
    <div class="col-md-7 w3ls_footer_grid1_right">
      <ul>
        <li><a href="<?php echo e(route('movies')); ?>">Movies</a></li>
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      </ul>
    </div>
    <div class="clearfix"> </div>
  </div>
</div><?php /**PATH C:\Users\zabran\laravel-kelas-xii-fixed (2)\laravel-kelas-xii-main\resources\views/templates/component/footer.blade.php ENDPATH**/ ?>